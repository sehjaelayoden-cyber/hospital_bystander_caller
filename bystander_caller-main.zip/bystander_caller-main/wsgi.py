# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2025 Ikhlas

from app import app

if __name__ == "__main__":
    app.run()